"""
08_download_sentinel2_gee.py — Download Sentinel-2 spectral indices via Google Earth Engine
Rhea Soil Nutrient Prediction Challenge

Prerequisites:
  1. pip install earthengine-api
  2. earthengine authenticate   (one-time; opens browser)

This script exports per-location median composites of:
  NDVI, EVI, SAVI, NDWI, BSI (Bare Soil Index), Clay Ratio, Iron Oxide Ratio

For points dated before 2017 (no S2 coverage), it falls back to Landsat 8.

NOTE: GEE export is asynchronous. For large datasets the script uses
      ee.Image.reduceRegion with a small buffer (500 m) for fast point sampling
      rather than full image export.

Run: python 08_download_sentinel2_gee.py
"""

import ee
import pandas as pd
import numpy as np
import json
import time
from pathlib import Path
from tqdm import tqdm

# ── Auth ──────────────────────────────────────────────────────────────────────
try:
    ee.Initialize(project='your-gee-project-id')   # ← replace with your GEE project
except Exception:
    ee.Authenticate()
    ee.Initialize(project='your-gee-project-id')

# ── Config ────────────────────────────────────────────────────────────────────
RAW    = Path("data/raw")
EXT    = Path("data/external")
EXT.mkdir(parents=True, exist_ok=True)

BUFFER_M  = 500   # meters buffer around each point
CLOUD_PCT = 20    # max cloud percentage for Sentinel-2
BATCH     = 50    # process in batches; GEE rate-limit friendly
SLEEP     = 0.5

S2_COLLECTION = "COPERNICUS/S2_SR_HARMONIZED"
L8_COLLECTION = "LANDSAT/LC08/C02/T1_L2"


def get_s2_indices(lon, lat, start_date, end_date):
    """Return spectral indices from Sentinel-2 median composite."""
    pt  = ee.Geometry.Point([lon, lat])
    roi = pt.buffer(BUFFER_M)

    img = (ee.ImageCollection(S2_COLLECTION)
           .filterDate(start_date, end_date)
           .filterBounds(roi)
           .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', CLOUD_PCT))
           .median())

    # Compute indices
    b2  = img.select('B2');  b3 = img.select('B3')
    b4  = img.select('B4');  b5 = img.select('B5')
    b8  = img.select('B8');  b8a= img.select('B8A')
    b11 = img.select('B11'); b12= img.select('B12')

    ndvi   = b8.subtract(b4).divide(b8.add(b4)).rename('NDVI')
    evi    = (b8.subtract(b4).divide(b8.add(b4.multiply(6)).subtract(b2.multiply(7.5)).add(1)).multiply(2.5)).rename('EVI')
    ndwi   = b3.subtract(b8).divide(b3.add(b8)).rename('NDWI')
    bsi    = (b11.add(b4).subtract(b8a.add(b2))).divide(b11.add(b4).add(b8a).add(b2)).rename('BSI')
    clay   = b11.divide(b8a).rename('ClayRatio')
    iron   = b4.divide(b2).rename('IronOxide')
    savi   = b8.subtract(b4).divide(b8.add(b4).add(0.5)).multiply(1.5).rename('SAVI')

    composite = img.select(['B2','B3','B4','B8','B11','B12']) \
                   .addBands([ndvi, evi, ndwi, bsi, clay, iron, savi])

    result = composite.reduceRegion(
        reducer  = ee.Reducer.mean(),
        geometry = roi,
        scale    = 20,
        maxPixels= 1e9
    )
    return result.getInfo()


def get_l8_indices(lon, lat, start_date, end_date):
    """Fallback: Landsat 8 spectral indices."""
    pt  = ee.Geometry.Point([lon, lat])
    roi = pt.buffer(BUFFER_M)

    img = (ee.ImageCollection(L8_COLLECTION)
           .filterDate(start_date, end_date)
           .filterBounds(roi)
           .median())

    # Landsat 8 band names: SR_B2=Blue, SR_B3=Green, SR_B4=Red, SR_B5=NIR, SR_B6=SWIR1
    b2  = img.select('SR_B2'); b3 = img.select('SR_B3')
    b4  = img.select('SR_B4'); b5 = img.select('SR_B5')
    b6  = img.select('SR_B6')

    ndvi = b5.subtract(b4).divide(b5.add(b4)).rename('NDVI')
    ndwi = b3.subtract(b5).divide(b3.add(b5)).rename('NDWI')
    bsi  = (b6.add(b4).subtract(b5.add(b2))).divide(b6.add(b4).add(b5).add(b2)).rename('BSI')
    iron = b4.divide(b2).rename('IronOxide')

    composite = img.select(['SR_B2','SR_B3','SR_B4','SR_B5','SR_B6']) \
                   .addBands([ndvi, ndwi, bsi, iron])

    result = composite.reduceRegion(
        reducer  = ee.Reducer.mean(),
        geometry = roi,
        scale    = 30,
        maxPixels= 1e9
    )
    return result.getInfo()


def process_df(df: pd.DataFrame, label: str) -> pd.DataFrame:
    records = []
    cache_path = EXT / f"s2_cache_{label}.jsonl"

    # Load existing cache
    done_ids = set()
    if cache_path.exists():
        with open(cache_path) as f:
            for line in f:
                rec = json.loads(line)
                done_ids.add(rec['ID'])

    with open(cache_path, 'a') as cache_file:
        for _, row in tqdm(df.iterrows(), total=len(df), desc=f"Sentinel-2 [{label}]"):
            if row['ID'] in done_ids:
                continue
            start = str(row.get('start_date', '2016-01-01'))[:10].replace('/','-')
            end   = str(row.get('end_date',   '2020-12-31'))[:10].replace('/','-')

            # Use S2 if dates are 2017+, else Landsat 8
            try:
                year_start = int(start[:4])
            except Exception:
                year_start = 2016

            try:
                if year_start >= 2017:
                    indices = get_s2_indices(row['Longitude'], row['Latitude'], start, end)
                    source  = 'S2'
                else:
                    indices = get_l8_indices(row['Longitude'], row['Latitude'], start, end)
                    source  = 'L8'
            except Exception as e:
                indices = {}
                source  = 'error'

            rec = {'ID': row['ID'], 'source': source}
            rec.update({f's2_{k}': v for k, v in (indices or {}).items()})
            cache_file.write(json.dumps(rec) + '\n')
            time.sleep(SLEEP)

    # Read complete cache into DataFrame
    rows = []
    with open(cache_path) as f:
        for line in f:
            rows.append(json.loads(line))
    result = pd.DataFrame(rows)
    drop_cols = ['source']
    return result.drop(columns=[c for c in drop_cols if c in result.columns])


if __name__ == '__main__':
    train = pd.read_csv(RAW / "Train.csv")[['ID','Latitude','Longitude','start_date','end_date']]
    test_dates = pd.read_csv(RAW / "Sample_Collection_Dates.csv")
    test  = pd.read_csv(RAW / "TestSet.csv")[['ID','Latitude','Longitude']]
    test  = test.merge(test_dates[test_dates['set']=='Test'][['ID','start_date','end_date']], on='ID', how='left')

    train_s2 = process_df(train, 'train')
    train_s2.to_csv(EXT / "sentinel2_train.csv", index=False)
    print(f"✅ Saved: data/external/sentinel2_train.csv  shape={train_s2.shape}")

    test_s2 = process_df(test, 'test')
    test_s2.to_csv(EXT / "sentinel2_test.csv", index=False)
    print(f"✅ Saved: data/external/sentinel2_test.csv   shape={test_s2.shape}")
