"""
06_download_soilgrids.py — Batch-download SoilGrids 2.0 features for all locations
Rhea Soil Nutrient Prediction Challenge

SoilGrids REST API (free, no auth required):
https://rest.isric.org/soilgrids/v2.0/properties/query

Properties returned: phh2o, clay, sand, silt, soc, cec, bdod, nitrogen
Depths: 0-5cm, 5-15cm, 15-30cm, 30-60cm

Run: python 06_download_soilgrids.py
     (takes ~2-4 hrs for 50k points; uses caching to resume)
"""

import requests
import pandas as pd
import numpy as np
import json
import time
from pathlib import Path
from tqdm import tqdm

# ── Config ────────────────────────────────────────────────────────────────────
RAW  = Path("data/raw")
EXT  = Path("data/external")
EXT.mkdir(parents=True, exist_ok=True)

CACHE_DIR = EXT / "soilgrids_cache"
CACHE_DIR.mkdir(exist_ok=True)

API_URL   = "https://rest.isric.org/soilgrids/v2.0/properties/query"
PROPS     = ["phh2o","clay","sand","silt","soc","cec","bdod","nitrogen"]
DEPTHS    = ["0-5cm","5-15cm","15-30cm","30-60cm"]

SLEEP_OK  = 0.3   # seconds between requests when successful
SLEEP_ERR = 5.0   # seconds to wait after rate-limit / error
MAX_RETRY = 3


def fetch_point(lat: float, lon: float) -> dict | None:
    """Fetch SoilGrids data for a single lat/lon point. Returns dict or None."""
    params = {
        "lon": round(lon, 5),
        "lat": round(lat, 5),
        "property": PROPS,
        "depth": DEPTHS,
    }
    for attempt in range(MAX_RETRY):
        try:
            r = requests.get(API_URL, params=params, timeout=30)
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 429:
                time.sleep(SLEEP_ERR * (attempt + 1))
            else:
                time.sleep(SLEEP_ERR)
        except Exception as e:
            time.sleep(SLEEP_ERR)
    return None


def parse_response(data: dict, lat: float, lon: float) -> dict:
    """Flatten the JSON response into a single-row dict."""
    row = {'Latitude': lat, 'Longitude': lon}
    if data is None or 'properties' not in data:
        return row
    for layer in data['properties']['layers']:
        prop = layer['name']
        for depth_info in layer['depths']:
            depth_label = depth_info['label'].replace(' ', '')
            mean_val    = depth_info['values'].get('mean')
            key         = f"sg_{prop}_{depth_label}"
            row[key]    = mean_val
    return row


def cache_path(lat: float, lon: float) -> Path:
    key = f"{round(lat,4)}_{round(lon,4)}"
    return CACHE_DIR / f"{key}.json"


def load_cache(lat: float, lon: float):
    p = cache_path(lat, lon)
    if p.exists():
        with open(p) as f:
            return json.load(f)
    return None


def save_cache(lat: float, lon: float, data):
    with open(cache_path(lat, lon), 'w') as f:
        json.dump(data, f)


def process_set(df: pd.DataFrame, label: str) -> pd.DataFrame:
    results = []
    for _, row in tqdm(df.iterrows(), total=len(df), desc=label):
        lat, lon = row['Latitude'], row['Longitude']
        cached = load_cache(lat, lon)
        if cached is not None:
            data = cached
        else:
            data = fetch_point(lat, lon)
            save_cache(lat, lon, data)
            time.sleep(SLEEP_OK)

        parsed = parse_response(data, lat, lon)
        parsed['ID'] = row['ID']
        results.append(parsed)

    result_df = pd.DataFrame(results)
    # Move ID to front
    cols = ['ID'] + [c for c in result_df.columns if c != 'ID']
    return result_df[cols]


# ── Run ───────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    train = pd.read_csv(RAW / "Train.csv")[['ID','Latitude','Longitude']].drop_duplicates('ID')
    test  = pd.read_csv(RAW / "TestSet.csv")[['ID','Latitude','Longitude']].drop_duplicates('ID')

    print(f"Train: {len(train)} unique points")
    print(f"Test:  {len(test)}  unique points")

    train_sg = process_set(train, "Train SoilGrids")
    train_sg.to_csv(EXT / "soilgrids_train.csv", index=False)
    print(f"✅ Saved: data/external/soilgrids_train.csv  shape={train_sg.shape}")

    test_sg = process_set(test, "Test SoilGrids")
    test_sg.to_csv(EXT / "soilgrids_test.csv", index=False)
    print(f"✅ Saved: data/external/soilgrids_test.csv   shape={test_sg.shape}")
